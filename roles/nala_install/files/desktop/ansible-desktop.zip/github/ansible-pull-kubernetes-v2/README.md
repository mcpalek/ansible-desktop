# ansible-pull-kubernetes-v2
install kubernetes with ansible using ansible roles to organize better the playbooks
