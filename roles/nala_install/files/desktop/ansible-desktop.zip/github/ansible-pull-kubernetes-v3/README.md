# ansible-pull-kubernetes-v3
Here I am adding the worker nodes also
