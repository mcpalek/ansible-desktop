#!/bin/bash

echo "This is the test ansible app"

exit 0;
