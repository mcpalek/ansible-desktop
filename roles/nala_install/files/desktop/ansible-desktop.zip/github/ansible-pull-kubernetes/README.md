# ansible-pull-kubernetes
I will start this with just some simple things