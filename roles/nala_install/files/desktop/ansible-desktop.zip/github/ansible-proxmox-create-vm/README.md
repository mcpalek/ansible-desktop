# ansible
This is my first ansible playbook.
With this palybook I am installing different Linux operation systems on my Proxmox server
