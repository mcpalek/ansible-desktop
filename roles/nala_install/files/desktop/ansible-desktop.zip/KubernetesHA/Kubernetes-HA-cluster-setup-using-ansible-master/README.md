# Kubernetes-HA-cluster-setup-using-ansible
https://youtu.be/zjl6RKe13gw
